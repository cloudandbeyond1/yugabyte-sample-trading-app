import TrafficLocation from "../../components/traffic_location/TrafficLocation";
import { makeStyles } from "@material-ui/core/styles";
import Phone from "../../components/phone/Phone";
import Bottommenu from "./Bottommenu";
import Sample from "./chart";
// import Sample from "./Sample";
import TLRButton from "../../components/tlr_button/TLRButton";
import { useNavigate } from "react-router-dom";
import { Typography } from "@material-ui/core";
import { ReactComponent as AppLogo } from "../../assets/yugastore-logo.svg";
import AppContext from "../../contexts/AppContext";
import { useContext } from "react";
import { ReactComponent as LoadingCircles } from "../../yugabyted-ui/assets/Default-Loading-Circles.svg";
import Menu from "./menu";
// import Sample from "./Sample";
const useStyles = makeStyles((theme) => {
  return {
    landingWrapper: {
      paddingTop: theme.spacing(4),
      paddingBottom: theme.spacing(4),
      paddingLeft: theme.spacing(4),
      paddingRight: theme.spacing(4),
      height: "600px",
      width: "100%",
      display: "flex",
      flex: "1 1 auto",
      flexDirection: "column",
      alignItems: "center",
      //   justifyContent: "center",
      overflowY: "scroll",
      overflowX: "hidden",
    },
    landingHeader: {
      flexBasis: "300px",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      gap: "30px",
    },
    logo: {
      height: "88px",
      width: "88px",
    },
    appHeading: {
      color: theme.palette.text.primaryPurple,
      fontSize: "30px",
      fontWeight: "500",
    },
    landingContent: {
      display: "flex",
      flexDirection: "column",
      flex: "1 1 auto",
      alignItems: "center",
      justifyContent: "center",
      gap: "30px",
    },
    instructions: {
      textAlign: "center",
      width: "80%",
    },
    loadingCircles: {
      height: "40px",
      width: "40px",
    },
  };
});

export default function Portfolio() {
  const classes = useStyles();
  let navigate = useNavigate();
  const { loading } = useContext(AppContext);
  return (
    <Phone>
      <div className={classes.landingWrapper}>
        <div className={classes.landingHeader}>
  
  {/* <Menu /> */}
  <main className="main-content position-relative border-radius-lg ">
    
    <nav className="navbar navbar-main navbar-expand-lg float-end px-0 shadow-none border-radius-xl z-index-sticky " id="navbarBlur" data-scroll="false">
      <div className="container-fluid py-1 px-3">

        <div className="sidenav-toggler sidenav-toggler-inner d-xl-block d-none ">
          <a href="javascript:;" className="nav-link p-0">
            <div className="sidenav-toggler-inner">
              <i className="sidenav-toggler-line bg-dark"></i>
              <i className="sidenav-toggler-line bg-dark"></i>
              <i className="sidenav-toggler-line bg-dark"></i>
            </div>
          </a>
        </div>
        <div className="collapse navbar-collapse mt-sm-0 mt-2 me-md-0 me-sm-4" id="navbar">
         
          <ul className="navbar-nav justify-content-end">
            <li className="nav-item d-flex align-items-center">
              <a href="" className="nav-link text-dark font-weight-bold ps-2"  onClick={() => {navigate("/main");}}>
                <i className="fa fa-user me-sm-1 text-dark"></i>
                {/* <span className="d-sm-inline d-none">Sign Up</span> */}
              </a>
            </li>
            <li className="nav-item d-xl-none px-2 d-flex align-items-center">
              <a href="javascript:;" className="nav-link text-dark p-0" id="iconNavbarSidenav">
                <div className="sidenav-toggler-inner text-dark ms-4">
                  <i className="sidenav-toggler-line bg-menu"></i>
                  <i className="sidenav-toggler-line bg-menu"></i>
                  <i className="sidenav-toggler-line bg-menu"></i>
                </div>
              </a>
            </li>
            <li className="nav-item d-flex align-items-center">
              <a href="javascript:;" className="nav-link text-dark p-0">
                <i className="fa fa-cog fixed-plugin-button-nav cursor-pointer text-dark"></i>
              </a>
            </li>
            <li className="nav-item dropdown px-2 d-flex align-items-center">
              <a href="javascript:;" className="nav-link text-white p-0" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                <i className="fa fa-bell cursor-pointer text-dark"></i>
              </a>
              <ul className="dropdown-menu dropdown-menu-end px-2 py-3 me-sm-n4" aria-labelledby="dropdownMenuButton">
                <li className="mb-2">
                  <a className="dropdown-item border-radius-md" href="javascript:;">
                    <div className="d-flex py-1">
                     
                      <div className="d-flex flex-column justify-content-center">
                        <h6 className="text-sm font-weight-normal mb-1">
                          <span className="font-weight-bold text-dark">New update</span> from user
                        </h6>
                        <p className="text-xs text-secondary mb-0">
                          <i className="fa fa-clock me-1"></i>
                          13 minutes ago
                        </p>
                      </div>
                    </div>
                  </a>
                </li>
                <li className="mb-2">
                  <a className="dropdown-item border-radius-md" href="javascript:;">
                    <div className="d-flex py-1">
                     
                      <div className="d-flex flex-column justify-content-center">
                        <h6 className="text-sm font-weight-normal mb-1">
                          <span className="font-weight-bold">New User</span> Added
                        </h6>
                        <p className="text-xs text-secondary mb-0">
                          <i className="fa fa-clock me-1"></i>
                          1 day
                        </p>
                      </div>
                    </div>
                  </a>
                </li>
                {/* <li>
                  <a className="dropdown-item border-radius-md" href="javascript:;">
                    <div className="d-flex py-1">
                      <div className="avatar avatar-sm bg-gradient-secondary  me-3  my-auto">
                        <svg width="12px" height="12px" viewBox="0 0 43 36" version="1.1" xmlns="#" xmlns:xlink="#">
                          <title>credit-card</title>
                          <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                            <g transform="translate(-2169.000000, -745.000000)" fill="#FFFFFF" fill-rule="nonzero">
                              <g transform="translate(1716.000000, 291.000000)">
                                <g transform="translate(453.000000, 454.000000)">
                                  <path className="color-background" d="M43,10.7482083 L43,3.58333333 C43,1.60354167 41.3964583,0 39.4166667,0 L3.58333333,0 C1.60354167,0 0,1.60354167 0,3.58333333 L0,10.7482083 L43,10.7482083 Z" opacity="0.593633743"></path>
                                  <path className="color-background" d="M0,16.125 L0,32.25 C0,34.2297917 1.60354167,35.8333333 3.58333333,35.8333333 L39.4166667,35.8333333 C41.3964583,35.8333333 43,34.2297917 43,32.25 L43,16.125 L0,16.125 Z M19.7083333,26.875 L7.16666667,26.875 L7.16666667,23.2916667 L19.7083333,23.2916667 L19.7083333,26.875 Z M35.8333333,26.875 L28.6666667,26.875 L28.6666667,23.2916667 L35.8333333,23.2916667 L35.8333333,26.875 Z"></path>
                                </g>
                              </g>
                            </g>
                          </g>
                        </svg>
                      </div>
                      <div className="d-flex flex-column justify-content-center">
                        <h6 className="text-sm font-weight-normal mb-1">
                          Payment successfully completed
                        </h6>
                        <p className="text-xs text-secondary mb-0">
                          <i className="fa fa-clock me-1"></i>
                          2 days
                        </p>
                      </div>
                    </div>
                  </a>
                </li> */}
              </ul>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    
    <div className="container-fluid py-4 mt-3">
      <div className="row">
        <div className="col-xs-12">
          <h4 className="mb-3">Portfolio</h4>
          <p className="badgge">
            <span className="badge badge-success"><i className="fa fa-caret-up text-success"></i>  810 %</span>
          </p>
         
        </div>
      </div>
      <div className="row mt-2 bg-white">
        <div className="col-xs-12 mb-4 mb-lg-0 ">
          <div className="card z-index-2 h-100">
            <div className="card-header pb-0 pt-3 bg-transparent">
              <h6 className="text-capitalize">Your Total Balance</h6>
              
              <h6 className="text-capitalize"><span style={{fontSize:"30px"}}>$25,901.0.41</span>
              </h6>
              
            
            </div>

            <div className="card-body p-3">
            {/* <Sample /> */}
              <div className="chart">
                <Sample />

                {/* <img src="http://rezingo.com/tradex/assets/img/barchart.png" className="responsive" /> */}
                {/* <canvas id="bar-chart" className="chart-canvas" height="300"></canvas> */}
              </div>
            </div>

          <div className="center mb-3 pt-5" style={{zIndex:"999",marginTop:"20px"}}>
            <a className="btn-pill mx-2" href="#">12H</a>
            <a className="btn-pill mx-2" href="#">1D</a>
            <a className="btn-pill mx-2 active" href="#">1W</a>
            <a className="btn-pill mx-2" href="#">1M</a>
            <a className="btn-pill mx-2" href="#">1Y</a>
            
          </div>
            
          </div>
        </div>
        <div className="col-xs-5">
         
        </div>
      </div>
     
      <div className="row">
        
        <div className="col-xs-12 mt-3">
          <div className="">
            <div className="card">
              <div className="card-header pb-0 p-3">
                <div className="d-flex justify-content-between">
                  <h6 className="mb-2">Top Stocks</h6>
                  <a href="#"><p className="mb-2 float-end text-primary font-weight-bold">View all</p></a>
                </div>
              </div>
              <div className="table-responsive">
                <table className="table align-items-center ">
                  <tbody>
                    <tr>
                      <td className="w-30">
                        <div className="d-flex py-1 align-items-center">
                          <div>
                            <img src="http://rezingo.com/tradex/assets/img/microsoft.png" className="iconsize"/>
                          </div>
                          <div className="ms-2">
                            <h6 className="text-sm mb-1">Microsoft</h6>
                            <p className="text-xs font-weight-bold mb-0">Microsoft Corp.</p>
                          </div>
                        </div>
                      </td>
                      <td>
                        <div className="text-center">
                          <img src="http://rezingo.com/tradex/assets/img/chartblue.png" className="chartsize" alt=""/>
                        </div>
                      </td>
                        <td>
                        <div className="text-center">
                        
                          <h6 className="text-sm mb-0">$213.10</h6>
                          <p className="text-sm mb-0 text-info" style={{fontSize: "8px"}}>
                            <i className="fas fa-arrow-down" aria-hidden="true" style={{fontSize:"10px"}}></i> 29.9%</p>
                        </div>
                      </td>
                     
                    </tr>
                    <tr>
                      <td className="w-30">
                        <div className="d-flex py-1 align-items-center">
                          <div>
                            <img src="http://rezingo.com/tradex/assets/img/google.png" className="iconsize"/>
                          </div>
                          <div className="ms-2">
                            <h6 className="text-sm mb-1">Google</h6>
                            <p className="text-xs font-weight-bold mb-0">Alphabet Inc.</p>
                          </div>
                        </div>
                      </td>
                      <td>
                        <div className="text-center">
                          
                          <img src="http://rezingo.com/tradex/assets/img/chartgreen.png" className="chartsize" alt=""/>
                        </div>
                      </td>
                        <td>
                          <div className="text-center">
                         
                            <h6 className="text-sm mb-0">$213.10</h6>
                            <p className="text-sm mb-0 text-success">
                              <i className="fas fa-arrow-up" aria-hidden="true" style={{fontSize:"10px"}}></i> 2.9%</p>
                          </div>
                        </td>
                     
					 
                    </tr>
                    <tr>
                      <td className="w-30">
                        <div className="d-flex py-1 align-items-center">
                          <div>
                            <img src="http://rezingo.com/tradex/assets/img/spotify.png" className="iconsize"/>
                          </div>
                          <div className="ms-2">
                            <h6 className="text-sm mb-1">Google</h6>
                            <p className="text-xs font-weight-bold mb-0">Alphabet Inc.</p>
                          </div>
                        </div>
                      </td>
                      <td>
                        <div className="text-center">
                       
                          <img src="http://rezingo.com/tradex/assets/img/chartyellow.png" className="chartsize" alt=""/>
                        </div>
                      </td>
                        <td>
                        <div className="text-center">
                         
						 
                          <h6 className="text-sm mb-0">$213.10</h6>
                          <p className="text-sm mb-0 text-warning">
                            <i className="fas fa-arrow-up" aria-hidden="true" style={{fontSize:"10px"}}></i> 9.9%</p>
                        </div>
                      </td>
                   
				   
                    </tr>
                    
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>


      </div>
      <Bottommenu />
      <footer className="footer">
        {/* <div className="container-fluid">
        <div className="row">

          <div className="col-xs-12">
          <div class="menu-mob justify-content-center d-block">
          <div class="center my-3">
            <a class="btn-pill2" href="#">

              <i class="fa fa-home me-sm-1"></i>
                
                <br/>
                <p>
                Home</p>
            </a>
            <a class="btn-pill2" href="#">

              <i class="fa fa-window-restore me-sm-1"></i>
                
                <br/>
                <p>
                Portfolio</p>

            </a>
            <a class="btn-pill2 active" href="#">
              <div>
              <img src="http://rezingo.com/tradex/assets/img/menurnd.png" class="menurnd" alt=""/>
              <i class="fa fa-exchange me-sm-1 menucenter"></i>
            </div>
            </a>
            <a class="btn-pill2" href="#">

              <i class="fa fa-history me-sm-1"></i>
                
                <br/>
                <p>
                History</p>
            </a>
            <a class="btn-pill2 " href="#">

              <i class="fa fa-user-circle me-sm-1"></i>
                <br/>
                <p>
                Profile</p>
            </a>
            
          </div>
        </div>


          </div>
        </div> 
        
          
        
        </div> */}
      </footer>
    </div>
  </main>

        </div>
      </div>

     
    </Phone>
  );
}
