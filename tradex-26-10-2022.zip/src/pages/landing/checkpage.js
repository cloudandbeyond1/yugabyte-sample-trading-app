import TrafficLocation from "../../components/traffic_location/TrafficLocation";
import { makeStyles } from "@material-ui/core/styles";
import Phone from "../../components/phone/Phone";
import Bottommenu from "./Bottommenu";
// import Sample from "./Sample";
import TLRButton from "../../components/tlr_button/TLRButton";
import { useNavigate } from "react-router-dom";
import { Typography } from "@material-ui/core";
import { ReactComponent as AppLogo } from "../../assets/yugastore-logo.svg";
import AppContext from "../../contexts/AppContext";
import { useContext } from "react";
import { ReactComponent as LoadingCircles } from "../../yugabyted-ui/assets/Default-Loading-Circles.svg";
import Menu from "./menu";
// import Sample from "./Sample";
const useStyles = makeStyles((theme) => {
  return {
    landingWrapper: {
      paddingTop: theme.spacing(4),
      paddingBottom: theme.spacing(4),
      paddingLeft: theme.spacing(4),
      paddingRight: theme.spacing(4),
      height: "600px",
      width: "100%",
      display: "flex",
      flex: "1 1 auto",
      flexDirection: "column",
      alignItems: "center",
      //   justifyContent: "center",
      overflowY: "scroll",
      overflowX: "hidden",
    },
    landingHeader: {
      flexBasis: "300px",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      gap: "30px",
    },
    logo: {
      height: "88px",
      width: "88px",
    },
    appHeading: {
      color: theme.palette.text.primaryPurple,
      fontSize: "30px",
      fontWeight: "500",
    },
    landingContent: {
      display: "flex",
      flexDirection: "column",
      flex: "1 1 auto",
      alignItems: "center",
      justifyContent: "center",
      gap: "30px",
    },
    instructions: {
      textAlign: "center",
      width: "80%",
    },
    loadingCircles: {
      height: "40px",
      width: "40px",
    },
  };
});

export default function Checkpage() {
  const classes = useStyles();
  let navigate = useNavigate();
  const { loading } = useContext(AppContext);
  return (
    <Phone>
      <div className={classes.landingWrapper}>
        <div className={classes.landingHeader}>
  
        <main className="main-content">
    <section>
      <div className="page-header">
        <div className="container px-0 mx-0">

          <div className="row">

            <img src="http://rezingo.com/tradex/assets/img/purple.png" className="bgcurve" alt=""/>

          </div>

          <div className="row loaderwrap"> 

            <img src="http://rezingo.com/tradex/assets/img/loaderblue.png" className="loader" alt="" />

          </div>

          <div className="row">

              <div className="card card-plain">

                
                <div className="card-header pb-4 text-left">

                  <h4 className="font-weight-bolder text-center">Checking! Please wait...</h4>
                 <p className="mb-0 text-center">Your account is being checked before ready to use.</p>

                </div>
             
    			    <div className="card-body">

                <div className="text-center mt-4 pt-4">
                  <button type="button" className="btn bg-primary w-100 my-4 mb-2 text-white text-upper" onClick={() => {navigate("/main");}}>BACK TO HOME</button>
                </div>

              </div>
			  
               
</div>
          
          </div>
        </div>

      </div>

    </section>

  </main>

        </div>
      </div>

     
    </Phone>
  );
}
