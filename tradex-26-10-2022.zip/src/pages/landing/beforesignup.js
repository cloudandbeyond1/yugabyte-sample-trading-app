import TrafficLocation from "../../components/traffic_location/TrafficLocation";
import { makeStyles } from "@material-ui/core/styles";
import Phone from "../../components/phone/Phone";
import Bottommenu from "./Bottommenu";
// import Sample from "./Sample";
import TLRButton from "../../components/tlr_button/TLRButton";
import { useNavigate } from "react-router-dom";
import { Typography } from "@material-ui/core";
import { ReactComponent as AppLogo } from "../../assets/yugastore-logo.svg";
import AppContext from "../../contexts/AppContext";
import { useContext } from "react";
import { ReactComponent as LoadingCircles } from "../../yugabyted-ui/assets/Default-Loading-Circles.svg";
import Menu from "./menu";
// import Sample from "./Sample";
const useStyles = makeStyles((theme) => {
  return {
    landingWrapper: {
      paddingTop: theme.spacing(4),
      paddingBottom: theme.spacing(4),
      paddingLeft: theme.spacing(4),
      paddingRight: theme.spacing(4),
      height: "600px",
      width: "100%",
      display: "flex",
      flex: "1 1 auto",
      flexDirection: "column",
      alignItems: "center",
      //   justifyContent: "center",
      overflowY: "scroll",
      overflowX: "hidden",
    },
    landingHeader: {
      flexBasis: "300px",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      gap: "30px",
    },
    logo: {
      height: "88px",
      width: "88px",
    },
    appHeading: {
      color: theme.palette.text.primaryPurple,
      fontSize: "30px",
      fontWeight: "500",
    },
    landingContent: {
      display: "flex",
      flexDirection: "column",
      flex: "1 1 auto",
      alignItems: "center",
      justifyContent: "center",
      gap: "30px",
    },
    instructions: {
      textAlign: "center",
      width: "80%",
    },
    loadingCircles: {
      height: "40px",
      width: "40px",
    },
  };
});

export default function Start() {
  const classes = useStyles();
  let navigate = useNavigate();
  const { loading } = useContext(AppContext);
  return (
    <Phone>
      <div className={classes.landingWrapper}>
        <div className={classes.landingHeader}>
  
  {/* <Menu /> */}
 
 
  <main className="main-content mt-2">
    <section>
      <div className="page-header">
        <div className="container mx-0 px-0">
          <div className="row">
            <div className="col-xs-12 d-flex flex-column mx-lg-0 mx-0 px-0">
              <div className="card card-plain">
                <div className="row">
                  <div className="col-xs-12 d-flex mx-1 flex-column">
                <i className="fa fa-arrow-left me-sm-1 mx-4 text-dark"></i>
              </div>
            </div>

                <div className="card-header pb-0 text-left">
                  <h2 className="font-weight-bolder mb-0">Let's you in</h2>
             
                </div>
             
                
			   <div className="card-body mb-3">

          <div className="min-vh-45">
          <div className="row mb-3">

            <a href="">
            
              <div className="btn-wrapper text-center px-0" >
              <div class="btn btn-neutral btn-icon btn-lg mb-2 px-4 py-4" >
                    <img class="w-15 float-start" src="http://rezingo.com/tradex/assets/img/fb.png" />
                 <span style={{lineHeight:"30px"}} className="font-weight-normal"> &nbsp; Continue with Facebook</span>
                  </div>
  </div>
                {/* <div className="fb">
                  <img src="http://rezingo.com/tradex/assets/img/fb.png" alt="" className="ico"/>  
                </div>
                
                <h6 className="icotxt px-2">Continue with Facebook</h6>

              </div> */}
          
            </a>
    
            <a href="">

            <div className="btn-wrapper text-center px-0" >
              <div class="btn btn-neutral btn-icon btn-lg mb-2 px-4 py-4" >
                    <img class="w-15 float-start" src="http://rezingo.com/tradex/assets/img/google.png" />
                 <span style={{lineHeight:"30px"}} className="font-weight-normal"> &nbsp; Continue with Google</span>
                  </div>
  </div>

              {/* <div className="gowrap">

                <div className="go">

                  <img src="http://rezingo.com/tradex/assets/img/google.png" alt="" className="ico"/>  

                </div>

                <p className="icotxt" style={{left: "10% important"}}>Continue with Google</p>

              </div> */}
    
            </a>

            <a href="" >

            <div className="btn-wrapper text-center px-0" >
              <div class="btn btn-neutral btn-icon btn-lg mb-2 px-4 py-4" >
                    <img class="w-15 float-start" src="http://rezingo.com/tradex/assets/img/apple.png" />
                 <span style={{lineHeight:"30px"}} className="font-weight-normal"> &nbsp; Continue with Apple</span>
                  </div>
  </div>
              {/* <div className="appwrap">

                <div className="app">

                  <img src="http://rezingo.com/tradex/assets/img/apple.png" alt="" className="ico"/>  

                </div>

                <p className="icotxt" style={{left: "10% important"}}>Continue with Apple</p>

              </div> */}
            
            </a>
            </div>
          </div>

                <form role="form mx-5 mt-3">
				  
                  <div className="mb-3 position-relative text-center">

                    <p className="text-sm font-weight-bold mb-4 text-secondary text-border d-inline z-index-2 bg-white px-3">
                      or
                    </p>

                  </div>

                  <div className="text-center mx-0 px-0">

                    <button type="button" className="btn bg-primary mx-0 mt-1 px-5 mb-2 text-white text-upper font-weight-light w-100" >SIGN IN WITH PASSWORD</button>

                  </div>

                  <p className="text-sm mt-0 mb-0 text-center">Don't have an account? <a href="javascript:;" className="text-dark font-weight-bolder">Sign up</a></p>

                </form>

              </div>
			    
			     
			  
           
              </div>

            </div>

            {/* <div className="col-6 d-lg-flex d-none h-100 my-auto pe-0 position-absolute top-0 end-0 text-center justify-content-center flex-column">

              <div className="position-relative bg-primary h-100 m-1 p-2 border-radius-lg d-flex flex-column justify-content-center overflow-hidden">
            
      				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1563266.2300137707!2d-75.845583192264!3d40.06973811039393!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c0fb959e00409f%3A0x2cd27b07f83f6d8d!2sNew%20Jersey%2C%20USA!5e0!3m2!1sen!2sin!4v1666167663918!5m2!1sen!2sin" width="100%" height="100%" style={{border:"0"}} allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

              </div>
			  
            </div> */}

          </div>

        </div>

      </div>

    </section>

  </main>
  
      

        </div>
      </div>

     
    </Phone>
  );
}
