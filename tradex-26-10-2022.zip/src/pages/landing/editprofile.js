import TrafficLocation from "../../components/traffic_location/TrafficLocation";
import { makeStyles } from "@material-ui/core/styles";
import Phone from "../../components/phone/Phone";
import Bottommenu from "./Bottommenu";
// import Sample from "./Sample";
import TLRButton from "../../components/tlr_button/TLRButton";
import { useNavigate } from "react-router-dom";
import { Typography } from "@material-ui/core";
import { ReactComponent as AppLogo } from "../../assets/yugastore-logo.svg";
import AppContext from "../../contexts/AppContext";
import { useContext } from "react";
import { ReactComponent as LoadingCircles } from "../../yugabyted-ui/assets/Default-Loading-Circles.svg";
import Menu from "./menu";
// import Sample from "./Sample";
const useStyles = makeStyles((theme) => {
  return {
    landingWrapper: {
      paddingTop: theme.spacing(4),
      paddingBottom: theme.spacing(4),
      paddingLeft: theme.spacing(4),
      paddingRight: theme.spacing(4),
      height: "600px",
      width: "100%",
      display: "flex",
      flex: "1 1 auto",
      flexDirection: "column",
      alignItems: "center",
      //   justifyContent: "center",
      overflowY: "scroll",
      overflowX: "hidden",
    },
    landingHeader: {
      flexBasis: "300px",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      gap: "30px",
    },
    logo: {
      height: "88px",
      width: "88px",
    },
    appHeading: {
      color: theme.palette.text.primaryPurple,
      fontSize: "30px",
      fontWeight: "500",
    },
    landingContent: {
      display: "flex",
      flexDirection: "column",
      flex: "1 1 auto",
      alignItems: "center",
      justifyContent: "center",
      gap: "30px",
    },
    instructions: {
      textAlign: "center",
      width: "80%",
    },
    loadingCircles: {
      height: "40px",
      width: "40px",
    },
  };
});

export default function Editprofile() {
  const classes = useStyles();
  let navigate = useNavigate();
  const { loading } = useContext(AppContext);
  return (
    <Phone>
      <div className={classes.landingWrapper}>
        <div className={classes.landingHeader}>
  
  {/* <Menu /> */}
  {/* <div className="container position-sticky z-index-sticky top-0">
    <div className="row">
      <div className="col-xs-12">
       
        <nav className="navbar navbar-expand-lg blur border-radius-lg top-0 z-index-3 shadow position-absolute mt-4 py-2 start-0 end-0 mx-4">
          <div className="container-fluid ps-2 pe-0">
            <a className="navbar-brand m-0" href="" target="_blank">
              <img src="http://rezingo.com/tradex/assets/img/tradexlogo.png" className="navbar-brand-img h-100 img-fluid" alt="main_logo" style={{width: "200px"}}/>
             
            </a>
            <button className="navbar-toggler shadow-none ms-2" type="button" data-bs-toggle="collapse" data-bs-target="#navigation" aria-controls="navigation" aria-expanded="false" aria-label="Toggle navigation">
              <span className="navbar-toggler-icon mt-2">
                <span className="navbar-toggler-bar bar1"></span>
                <span className="navbar-toggler-bar bar2"></span>
                <span className="navbar-toggler-bar bar3"></span>
              </span>
            </button>
            <div className="collapse navbar-collapse w-100 pt-3 pb-2 py-lg-0" id="navigation">
              <ul className="navbar-nav navbar-nav-hover mx-auto">
                <li className="nav-item mx-2">
                  <a role="button" className="nav-link ps-2 d-flex  cursor-pointer align-items-center" href="index.html" target="_blank">
                    Dashboard
                   
                  </a>
                  
                </li>
                
                <li className="nav-item mx-2">
                  <a role="button" className="nav-link ps-2 d-flex  cursor-pointer align-items-center " id="dropdownMenuPages" data-bs-toggle="dropdown" aria-expanded="false">
                    Portfolio
                    
                  </a>
                  
                </li>

                <li className="nav-item mx-2">
                  <a role="button" className="nav-link ps-2 d-flex  cursor-pointer align-items-center " id="dropdownMenuPages" data-bs-toggle="dropdown" aria-expanded="false">
                    Log In
                  
                  </a>
                  
                </li>

                <li className="nav-item mx-2">
                  <a role="button" className="nav-link ps-2 d-flex  cursor-pointer align-items-center " id="dropdownMenuPages" data-bs-toggle="dropdown" aria-expanded="false">
                    User Profile
                   
                  </a>
                  
                </li>

                <li className="nav-item mx-2">
                  <a role="button" className="nav-link ps-2 d-flex  cursor-pointer align-items-center " id="dropdownMenuPages" data-bs-toggle="dropdown" aria-expanded="false">
                    Exchange
                  
                  </a>
                  
                </li>
                
              </ul>
              <ul className="navbar-nav d-lg-block d-none">
                <li className="nav-item">
                  <a href="#" className="btn btn-md btn-primary mb-0 me-1" onclick="smoothToPricing('pricing-argon')">Download Now</a>
                </li>
              </ul>
            </div>
          </div>
        </nav>
        
      </div>
    </div>
  </div> */}
  <main className="main-content mx-0">
    <section>
      <div className="page-header">
        <div className="container px-0">
          <div className="row">
            
            <div className="col-xs-12 d-flex flex-column mx-lg-0">
              <div className="row">
                <div className="col-xs-12 d-flex mx-4 flex-column">
                  <i className="fa fa-arrow-left fa-lg me-sm-1 text-dark pl-2"></i>
            </div>
            </div>
              <div className="card card-plain">
                <div className="card-header pb-0 text-left">
                  

                  <h4 className="font-weight-bolder">Fill your profile</h4>
                 <p className="mb-0">Don’t worry, you can always change it later</p>
                </div>
             
			   <div className="card-body">
                <form role="form">

                  <div className="mb-3 justify-content-center d-flex">
                  <label for="fileToUpload">
                    <div className="profile-pic" style={{backgroundImage: "url('http://rezingo.com/tradex/assets/img/profile.png')"}}>
                        <span className="fa fa-camera"> </span>
                        <span>Change Image</span>
                    </div>
                    </label>
                    <input type="File" name="fileToUpload" id="fileToUpload"/>
                  </div>
                  <div className="mb-3">
                    <input type="text" className="form-control" placeholder="Full Name" aria-label="fullname"/>
                  </div>

                  <div className="mb-3">
                    <input type="email" className="form-control" placeholder="Email" aria-label="Email"/>
                  </div>

                  <div className="mb-3">
                    <input type="password" className="form-control" placeholder="Password" aria-label="Password"/>
                  </div>
				  
                  <div className="mb-3">
                    <input type="text" className="form-control" placeholder="Phone Number" aria-label="number"/>
                  </div>
				  
                  <div className="text-center">
                    <button type="button" className="btn bg-primary w-100 my-4 mb-2 text-white text-upper" style={{backgroundColor:"#7879f1",color:"#fff"}} onClick={() => {navigate("/check");}}>Submit</button>
                  </div>
                  
                </form>
              </div>
			  
           
              </div>
            </div>
          
          </div>
        </div>
      </div>
    </section>
  </main>
      

        </div>
      </div>

     
    </Phone>
  );
}
