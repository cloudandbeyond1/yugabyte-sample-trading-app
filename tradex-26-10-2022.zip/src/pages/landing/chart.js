import React, { Component } from "react";
import Chart from "react-apexcharts";
// import "./Chart2.css";
class Sample extends Component {
  constructor(props) {
    super(props);

    this.state = {

      options: {
       
        xaxis: {
            
            categories: ["MON","TUE","WED","THU","FRI","SAT","SUN"]
        }
        
        
      },

 
      series: [
        {
            color :"#7879F1",
            data: [100, 25, 50, 75, 25, 30, 57],
            
        },
       
      
        
      ]
    };
  }

  render() {

    return (
      <div className="app bg-white">
        <div className="row">
          <div className="mixed-chart ">
            <Chart  
              options={this.state.options}
              series={this.state.series}
              type="bar"
              width="300"
            
            />
            
          </div>
        </div>
      </div>
    );
  }
}

export default Sample;