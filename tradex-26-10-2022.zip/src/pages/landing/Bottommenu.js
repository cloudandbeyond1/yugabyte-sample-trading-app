import React, { Component } from 'react'

export default class Bottommenu extends Component {
  render() {
    return (
        <div className="container-fluid">
        <div className="row">

          <div className="col-xs-12">
          <div class="menu-mob justify-content-center d-block">
          <div class="center my-3">
            <a class="btn-pill2" href="#">

              <i class="fa fa-home me-sm-1"></i>
                
                <br/>
                <p>
                Home</p>
            </a>
            <a class="btn-pill2" href="#">

              <i class="fa fa-window-restore me-sm-1"></i>
                
                <br/>
                <p>
                Portfolio</p>

            </a>
            <a class="btn-pill2 active" href="#">
              <div>
              <img src="http://rezingo.com/tradex/assets/img/menurnd.png" class="menurnd" alt=""/>
              <i class="fa fa-exchange me-sm-1 menucenter"></i>
            </div>
            </a>
            <a class="btn-pill2" href="#">

              <i class="fa fa-history me-sm-1"></i>
                
                <br/>
                <p>
                History</p>
            </a>
            <a class="btn-pill2 " href="#">

              <i class="fa fa-user-circle me-sm-1"></i>
                <br/>
                <p>
                Profile</p>
            </a>
            
          </div>
        </div>


          </div>
        </div> 
        
          
        
        </div>
    )
  }
}
