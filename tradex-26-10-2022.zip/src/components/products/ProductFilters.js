export default function ProductFilters() {
  return <div>Product Filters</div>;
}
