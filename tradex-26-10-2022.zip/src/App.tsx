import "leaflet/dist/leaflet.css";
import { Routes, Route } from "react-router-dom";
import Main from "./pages/main/Main";
import Landing from "./pages/main/startup";
import Login from "./pages/landing/login";
import Portfolio from "./pages/landing/portfolio";
import Dashboard from "./pages/main/dashboard";
import Editprofile from "./pages/main/editprofile";
import Start from "./pages/main/start";
import Success from "./pages/main/success";
import Checkpage from "./pages/main/check";
import ErrorPage from "./pages/error/ErrorPage";
import { AppProvider } from "./contexts/AppContext";
import { CssBaseline, ThemeProvider } from '@material-ui/core';
import { tlrTheme } from './yugabyted-ui/theme/tlrTheme'


import { makeStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import { useState } from "react";

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    flexWrap: "wrap",
    height: "100vh"
  },
  container: {
    height: "100%"
  }
}));

function App() {
  const classes = useStyles();
  return (
    <div>
      <AppProvider>
      <ThemeProvider theme={tlrTheme}>
        <CssBaseline />
          <div className={classes.root}>
            <Grid container className={classes.container}>
                <Routes>
                  <Route path="/" element={<Landing />}></Route>
                  <Route path="/login" element={<Login />}></Route>
                  <Route path="/portfolio" element={<Portfolio />}></Route>
                  <Route path="/main" element={<Main />}></Route>
                  <Route path="/dashboard" element={<Dashboard />}></Route>
                  <Route path="/editprofile" element={<Editprofile />}></Route>
                  <Route path="/start" element={<Start />}></Route>
                  <Route path="/success" element={<Success />}></Route>
                  <Route path="/check" element={<Checkpage />}></Route>
                </Routes>
            </Grid>
          </div>
        </ThemeProvider>
      </AppProvider>
    </div>
  );
}

export default App;

