declare namespace App {
  interface RouteParams {
    accountId: string;
    projectId: string;
    clusterId: string;
    tab: string;
    subTab: string;
    vpcId?: string;
    peeringId?: string;
  };
}

